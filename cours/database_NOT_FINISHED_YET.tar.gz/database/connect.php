<?php

mysql_connect("localhost", "root", "a123") or die("Impossible de se connecter : " . mysql_error());

echo 'Connexion réussie';

mysql_select_db('mineraux.db') or die('Problème dans la cabine');

echo 'Base de données selectionnée';
?>